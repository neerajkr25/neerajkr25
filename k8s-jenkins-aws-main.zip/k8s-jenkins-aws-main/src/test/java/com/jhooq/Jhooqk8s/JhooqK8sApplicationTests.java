package com.jhooq.Jhooqk8s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JhooqK8sApplicationTests {

	@Test
	void contextLoads() {
	}

}
